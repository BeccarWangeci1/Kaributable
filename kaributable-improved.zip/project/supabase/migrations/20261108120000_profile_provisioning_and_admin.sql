/*
  # Reliable profile provisioning + admin promotion

  1. Problem
     - The first migration relied on the browser inserting the profile row right after
       sign-up. When email confirmation is on there is no session at that moment, so the
       insert fails and the account is left with no profile.
     - `handle_new_profile()` took the role from the caller's JWT claims, which are absent
       when the row is created by the auth system rather than by the browser.
     - `profiles.email` was whatever the client sent.

  2. Changes
     - `handle_new_profile()` now reads role and email from `auth.users` by id. The role is
       still only ever 'customer' or 'vendor' on insert; 'admin' is never granted here.
     - New AFTER INSERT trigger on `auth.users` creates the profile server-side, so every
       account has exactly one profile regardless of confirmation settings or client errors.
       The client's own insert (still in the app as a fallback) becomes a harmless no-op.
     - `promote_to_admin(email)`: the only way to create an admin. Not callable by
       anon/authenticated users; run it from the SQL editor or with the service role.

  3. Security
     - All functions are SECURITY DEFINER with an empty search_path and schema-qualified
       names; EXECUTE is revoked from public roles.
*/

CREATE OR REPLACE FUNCTION public.handle_new_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  auth_role text;
  auth_email text;
BEGIN
  SELECT u.raw_app_meta_data ->> 'user_role', u.email
    INTO auth_role, auth_email
    FROM auth.users u
   WHERE u.id = NEW.id;

  -- Only 'vendor' is honoured from sign-up; everything else (including 'admin') is 'customer'.
  NEW.role := CASE WHEN auth_role = 'vendor' THEN 'vendor' ELSE 'customer' END;
  -- Email always mirrors the auth account, never a client-supplied value.
  NEW.email := COALESCE(auth_email, NEW.email);
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.create_profile_for_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, phone)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    COALESCE(NULLIF(btrim(NEW.raw_user_meta_data ->> 'full_name'), ''), split_part(COALESCE(NEW.email, 'guest'), '@', 1)),
    NULLIF(btrim(NEW.raw_user_meta_data ->> 'phone'), '')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.create_profile_for_new_user();

CREATE OR REPLACE FUNCTION public.promote_to_admin(target_email text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  target_id uuid;
BEGIN
  SELECT id INTO target_id FROM auth.users WHERE lower(email) = lower(target_email);
  IF target_id IS NULL THEN
    RAISE EXCEPTION 'No auth user with email %', target_email;
  END IF;

  UPDATE auth.users
     SET raw_app_meta_data = COALESCE(raw_app_meta_data, '{}'::jsonb) || '{"user_role":"admin"}'::jsonb
   WHERE id = target_id;

  -- Admins skip customer/vendor onboarding.
  UPDATE public.profiles SET role = 'admin', onboarding_complete = true WHERE id = target_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.handle_new_profile() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.create_profile_for_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.promote_to_admin(text) FROM PUBLIC, anon, authenticated;
