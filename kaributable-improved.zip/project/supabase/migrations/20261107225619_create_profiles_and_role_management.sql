/*
# Create profiles table with secure role management

1. Purpose
- Establishes the user profile system for the TABLELY marketplace.
- Each signed-in user has one profile row linked to their Supabase auth account.
- Roles (customer / vendor / admin) are managed securely and cannot be self-assigned.

2. New Tables
- `profiles`
  - `id` (uuid, primary key, matches auth.users.id)
  - `email` (text, the user's email from auth)
  - `full_name` (text, display name)
  - `phone` (text, Kenyan +254 format, nullable)
  - `role` (text, derived from auth metadata: customer / vendor / admin)
  - `avatar_url` (text, nullable)
  - `onboarding_complete` (boolean, default false — set true when profile setup done)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

3. Role Security Design
- During public registration, `supabase.auth.signUp()` is called with
  `options.data = { user_role: 'customer' | 'vendor' }`. This writes to
  `raw_user_meta_data` (user-visible, not secure).
- A trigger on `auth.users` (after insert) copies `user_role` into
  `raw_app_meta_data` (user-immutable, not writable by the browser client).
  The trigger ONLY accepts 'customer' or 'vendor'. Any other value (including
  'admin', null, or missing) defaults to 'customer'. This makes it impossible
  for a public sign-up to grant admin privileges.
- Admin accounts are created through a separate secure process (SECURITY
  DEFINER function called by an existing admin, or direct database action
  during initial setup). No public sign-up path can produce an admin.
- The `profiles.role` column is populated by a trigger from
  `raw_app_meta_data ->> 'user_role'` so it always reflects the secure value.
  The `profiles.role` column is NEVER accepted from a client insert or update —
  the column-level grant excludes it.

4. Security
- RLS enabled on `profiles`.
- `GRANT SELECT` to `anon` (so public vendor profile lookups work in Phase 2)
  and `authenticated`.
- `GRANT INSERT` to `authenticated` only, on the columns a user may set:
  (id, email, full_name, phone, avatar_url). NOT on `role` or
  `onboarding_complete` — those are managed by triggers / admin functions.
- `GRANT UPDATE` to `authenticated` on (full_name, phone, avatar_url,
  onboarding_complete). NOT on `role` or `email` (email is managed by auth).
- SELECT policy: a user can read their own profile; in Phase 2 public vendor
  profiles will be readable via a join. For Phase 1, own-profile only keeps
  things locked down.
- INSERT policy: a user can insert only their own profile row.
- UPDATE policy: a user can update only their own profile row.
- `profiles.role` has no client write path at all — it is set exclusively by
  the database trigger reading from app_metadata.

5. Triggers
- `handle_new_user_role()`: AFTER INSERT on auth.users. Reads
  `raw_user_meta_data ->> 'user_role'`. If it is 'vendor', sets app_metadata
  user_role to 'vendor'. Otherwise sets 'customer'. Never sets 'admin'.
- `handle_new_profile()`: AFTER INSERT on profiles. Sets `role` from the
  current user's app_metadata. Also sets `email` from auth.users if not
  provided. This ensures profiles.role always mirrors the secure metadata.
- `update_updated_at()`: BEFORE UPDATE on profiles, bumps updated_at.

6. Important Notes
- This migration does NOT create vendor, vendor_members, or any Phase 2
  tables. Phase 1 only needs profiles for authentication and basic profile
  setup.
- The `profiles` table is designed to be extended: Phase 2 will add vendor-
  specific tables that reference profiles.id.
- Email confirmation is intentionally OFF during development (Phase 1-2). It
  will be enabled before public launch.
- The role claim path in RLS policies is `auth.jwt() -> 'app_metadata' ->>
  'user_role'`, which is the correct path for raw_app_meta_data claims in
  Supabase's JWT.
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL,
  phone text,
  role text NOT NULL DEFAULT 'customer',
  avatar_url text,
  onboarding_complete boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Grant SELECT to anon (for future public vendor lookups) and authenticated
-- Grant INSERT/UPDATE to authenticated only, with column restrictions
GRANT SELECT ON profiles TO anon, authenticated;
GRANT INSERT (id, email, full_name, phone, avatar_url) ON profiles TO authenticated;
GRANT UPDATE (full_name, phone, avatar_url, onboarding_complete) ON profiles TO authenticated;

-- RLS Policies (Phase 1: own-profile access; Phase 2 adds public vendor reads)
DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Anon can select profiles that are published vendors (Phase 2 will add this).
-- For Phase 1, anon has SELECT grant but no matching policy = sees nothing,
-- which is correct — there is nothing public to show yet.

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Trigger: copy user_role from raw_user_meta_data to raw_app_meta_data
-- This runs AFTER a new auth user is created. It only accepts 'vendor';
-- everything else (including 'admin') becomes 'customer'.
-- Uses an UPDATE on auth.users to set app_metadata, which is the documented
-- way to set immutable metadata from a trigger.
CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  requested_role text;
  final_role text;
BEGIN
  requested_role := COALESCE(new.raw_user_meta_data ->> 'user_role', 'customer');

  -- Only 'vendor' is honored from public sign-up. 'admin' is NEVER set here.
  IF requested_role = 'vendor' THEN
    final_role := 'vendor';
  ELSE
    final_role := 'customer';
  END IF;

  -- Merge user_role into existing app_metadata (preserve other keys)
  new.raw_app_meta_data := jsonb_set(
    COALESCE(new.raw_app_meta_data, '{}'::jsonb),
    '{user_role}',
    to_jsonb(final_role)
  );

  RETURN new;
END;
$$;

-- Drop and recreate the trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user_role();

-- Trigger: set profiles.role from app_metadata on insert
-- This ensures the role column always mirrors the secure app_metadata value,
-- never a client-supplied value.
CREATE OR REPLACE FUNCTION public.handle_new_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  meta_role text;
BEGIN
  meta_role := COALESCE(
    current_setting('request.jwt.claims', true)::jsonb -> 'app_metadata' ->> 'user_role',
    'customer'
  );

  -- Only accept customer or vendor from metadata; never admin from this path
  IF meta_role = 'vendor' THEN
    NEW.role := 'vendor';
  ELSE
    NEW.role := 'customer';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_profile_insert ON profiles;
CREATE TRIGGER on_profile_insert
  BEFORE INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_profile();

-- Trigger: bump updated_at on profile update
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_profile_update ON profiles;
CREATE TRIGGER on_profile_update
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

-- Revoke execute on the trigger functions from public/anon (SECURITY DEFINER)
REVOKE EXECUTE ON FUNCTION public.handle_new_user_role() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_profile() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.update_updated_at() FROM PUBLIC, anon;