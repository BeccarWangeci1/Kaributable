/**
 * Kenyan phone helpers shared by sign-up and profile setup.
 * Canonical form is E.164: +254 followed by 9 digits (e.g. +254712345678).
 */

/** Digits after the +254 country code, accepting 07xx, 7xx, 254… and +254… input. */
function nationalDigits(value: string): string {
  let d = value.replace(/\D/g, '');
  if (d.startsWith('254')) d = d.slice(3);
  else if (d.startsWith('0')) d = d.slice(1);
  return d;
}

/** Normalise to +254XXXXXXXXX, or '' for empty input. Call on blur, not per keystroke. */
export function normalizeKenyanPhone(value: string): string {
  const d = nationalDigits(value).slice(0, 9);
  return d ? `+254${d}` : '';
}

/** Valid Kenyan mobile/landline: +254 then 9 digits starting 1 or 7 (Safaricom, Airtel, Telkom…). */
export function isValidKenyanPhone(value: string): boolean {
  return /^\+254[17]\d{8}$/.test(normalizeKenyanPhone(value));
}
