import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import type { AuthContextValue, Profile, UserRole } from '@/types';

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const ROLES: readonly UserRole[] = ['customer', 'vendor', 'admin'];

async function fetchProfile(uid: string): Promise<{ profile: Profile | null; failed: boolean }> {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle();
  if (error) {
    console.error('Error fetching profile:', error.message);
    return { profile: null, failed: true };
  }
  return { profile: (data as Profile | null) ?? null, failed: false };
}

/**
 * Self-heal accounts that have no profile row (sign-up insert failed, or email
 * confirmation was on so there was no session at sign-up time). `role` is never
 * sent: the database trigger derives it from the secure app_metadata.
 */
async function ensureProfile(user: User): Promise<void> {
  const meta = (user.user_metadata ?? {}) as { full_name?: string; phone?: string | null };
  const { error } = await supabase.from('profiles').upsert(
    {
      id: user.id,
      email: user.email ?? '',
      full_name: meta.full_name?.trim() || (user.email ?? '').split('@')[0] || 'Guest',
      phone: meta.phone || null,
    },
    { onConflict: 'id', ignoreDuplicates: true }
  );
  if (error) console.warn('Could not create missing profile:', error.message);
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<{ id: string; email: string } | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [profileError, setProfileError] = useState(false);
  // True until we know who the user is AND have resolved their profile, so route
  // guards never see "signed in but role unknown" as a final state.
  const [loading, setLoading] = useState(true);
  const userIdRef = useRef<string | null>(null);

  const loadProfileFor = useCallback(async (authUser: User) => {
    let result = await fetchProfile(authUser.id);
    if (!result.failed && !result.profile) {
      await ensureProfile(authUser);
      result = await fetchProfile(authUser.id);
    }
    if (userIdRef.current !== authUser.id) return; // signed out / switched meanwhile
    setProfile(result.profile);
    setProfileError(result.failed || !result.profile);
    setLoading(false);
  }, []);

  const handleSession = useCallback(
    (session: Session | null) => {
      const authUser = session?.user ?? null;

      if (!authUser) {
        userIdRef.current = null;
        setUser(null);
        setProfile(null);
        setProfileError(false);
        setLoading(false);
        return;
      }

      // Token refreshes re-emit the same user; don't refetch or flash a spinner.
      if (userIdRef.current === authUser.id) return;

      userIdRef.current = authUser.id;
      setUser({ id: authUser.id, email: authUser.email ?? '' });
      setProfile(null);
      setProfileError(false);
      setLoading(true);
      // Supabase advises against awaiting its own calls inside this callback
      // (can deadlock the auth lock), so defer to the next tick.
      setTimeout(() => void loadProfileFor(authUser), 0);
    },
    [loadProfileFor]
  );

  useEffect(() => {
    // INITIAL_SESSION fires on subscribe, so no separate getSession() call is needed.
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => handleSession(session));
    return () => subscription.unsubscribe();
  }, [handleSession]);

  const refreshProfile = useCallback(async () => {
    const uid = userIdRef.current;
    if (!uid) return;
    const result = await fetchProfile(uid);
    if (userIdRef.current !== uid) return;
    setProfile(result.profile);
    setProfileError(result.failed || !result.profile);
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    handleSession(null);
  }, [handleSession]);

  const role: UserRole | null = profile && ROLES.includes(profile.role) ? profile.role : null;

  const value = useMemo<AuthContextValue>(
    () => ({ user, profile, role, loading, profileError, signOut, refreshProfile }),
    [user, profile, role, loading, profileError, signOut, refreshProfile]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
