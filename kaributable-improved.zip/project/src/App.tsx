import { BrowserRouter, Routes, Route, Outlet, Link } from 'react-router-dom';
import { AuthProvider } from '@/context/AuthContext';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { ScrollManager } from '@/components/ScrollManager';
import { LandingPage } from '@/pages/LandingPage';
import { SignInPage } from '@/pages/SignInPage';
import { SignUpPage } from '@/pages/SignUpPage';
import { ProfileSetupPage } from '@/pages/ProfileSetupPage';
import { CustomerDashboard } from '@/pages/CustomerDashboard';
import { VendorDashboard } from '@/pages/VendorDashboard';
import { AdminDashboard } from '@/pages/AdminDashboard';
import { DashboardRouter } from '@/pages/DashboardRouter';
import { ComingSoonPage } from '@/pages/ComingSoonPage';

function PublicLayout() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen">
        <Outlet />
      </main>
      <Footer />
    </>
  );
}

function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-ivory-100 px-5 text-center">
      <p className="font-serif text-7xl font-600 text-terracotta-200">404</p>
      <h1 className="mt-4 font-serif text-2xl font-600 text-charcoal-700">Page not found</h1>
      <p className="mt-2 text-sm text-charcoal-400">
        The page you are looking for doesn't exist or has moved.
      </p>
      <Link to="/" className="btn-primary mt-6">
        Back to home
      </Link>
    </div>
  );
}

/** Placeholder pages that exist in each role's sidebar but arrive in Phase 2. */
const PLACEHOLDERS = {
  customer: [
    { path: 'saved', title: 'Saved vendors', description: 'Caterers you have bookmarked will appear here.' },
    { path: 'messages', title: 'Messages', description: 'Your conversations with vendors will appear here.' },
    { path: 'bookings', title: 'Bookings', description: 'Your enquiries and bookings will appear here.' },
    { path: 'settings', title: 'Settings', description: 'Manage your account preferences.' },
  ],
  vendor: [
    { path: 'enquiries', title: 'Enquiries', description: 'Customer enquiries and quotation requests will appear here.' },
    { path: 'bookings', title: 'Bookings', description: 'Your active and past bookings will appear here.' },
    { path: 'profile', title: 'Business profile', description: 'Edit your vendor business details, photos, and service areas.' },
    { path: 'settings', title: 'Settings', description: 'Manage your vendor account preferences.' },
  ],
  admin: [{ path: 'settings', title: 'Settings', description: 'Manage admin account preferences.' }],
} as const;

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <ScrollManager />
        <Routes>
          {/* Public pages with navbar + footer */}
          <Route element={<PublicLayout />}>
            <Route path="/" element={<LandingPage />} />
          </Route>

          {/* Auth pages (full-screen) */}
          <Route path="/signin" element={<SignInPage />} />
          <Route path="/signup" element={<SignUpPage />} />

          {/* Signed-in, but onboarding not required yet */}
          <Route element={<ProtectedRoute requireOnboarding={false} />}>
            <Route path="/profile-setup" element={<ProfileSetupPage />} />
          </Route>

          {/* Post-login router */}
          <Route element={<ProtectedRoute />}>
            <Route path="/dashboard-router" element={<DashboardRouter />} />
          </Route>

          {/* Role dashboards: one guarded layout per role so the shell persists between pages */}
          <Route element={<ProtectedRoute allowedRoles={['customer']} />}>
            <Route element={<DashboardLayout role="customer" />}>
              <Route path="/customer" element={<CustomerDashboard />} />
              {PLACEHOLDERS.customer.map(({ path, ...page }) => (
                <Route key={path} path={`/customer/${path}`} element={<ComingSoonPage {...page} />} />
              ))}
            </Route>
          </Route>

          <Route element={<ProtectedRoute allowedRoles={['vendor']} />}>
            <Route element={<DashboardLayout role="vendor" />}>
              <Route path="/vendor" element={<VendorDashboard />} />
              {PLACEHOLDERS.vendor.map(({ path, ...page }) => (
                <Route key={path} path={`/vendor/${path}`} element={<ComingSoonPage {...page} />} />
              ))}
            </Route>
          </Route>

          <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
            <Route element={<DashboardLayout role="admin" />}>
              <Route path="/admin" element={<AdminDashboard />} />
              {PLACEHOLDERS.admin.map(({ path, ...page }) => (
                <Route key={path} path={`/admin/${path}`} element={<ComingSoonPage {...page} />} />
              ))}
            </Route>
          </Route>

          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
