import type { ReactNode } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { dashboardPathFor, type UserRole } from '@/types';
import { FullPageSpinner } from '@/components/ui/Spinner';
import { Button } from '@/components/ui/Button';

interface ProtectedRouteProps {
  /** Wrap a single element, or omit to act as a layout route that renders nested routes. */
  children?: ReactNode;
  allowedRoles?: UserRole[];
  /** Send users who have not finished profile setup to /profile-setup first. Default true. */
  requireOnboarding?: boolean;
}

export function ProtectedRoute({ children, allowedRoles, requireOnboarding = true }: ProtectedRouteProps) {
  const { user, profile, role, loading, profileError, refreshProfile, signOut } = useAuth();
  const location = useLocation();

  if (loading) return <FullPageSpinner label="Preparing your table..." />;

  if (!user) {
    const from = `${location.pathname}${location.search}${location.hash}`;
    return <Navigate to="/signin" state={{ from }} replace />;
  }

  // Signed in but we can't tell who they are. Never fall through to the page.
  if (profileError || !profile || !role) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-ivory-100 px-5 text-center">
        <h1 className="font-serif text-2xl font-600 text-charcoal-700">We couldn't load your account</h1>
        <p className="max-w-sm text-sm text-charcoal-400">
          Check your connection and try again. If this keeps happening, sign out and back in.
        </p>
        <div className="flex gap-3">
          <Button onClick={() => void refreshProfile()}>Try again</Button>
          <Button variant="secondary" onClick={() => void signOut()}>
            Sign out
          </Button>
        </div>
      </div>
    );
  }

  if (allowedRoles && !allowedRoles.includes(role)) {
    return <Navigate to={dashboardPathFor(role)} replace />;
  }

  if (requireOnboarding && role !== 'admin' && !profile.onboarding_complete) {
    return <Navigate to="/profile-setup" replace />;
  }

  return <>{children ?? <Outlet />}</>;
}
