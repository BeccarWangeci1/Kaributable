import { Loader2 } from 'lucide-react';
import { cn } from '@/utils/cn';

export function Spinner({ className, size = 20 }: { className?: string; size?: number }) {
  return (
    <Loader2
      className={cn('animate-spin text-terracotta-400', className)}
      size={size}
      aria-label="Loading"
    />
  );
}

export function FullPageSpinner({ label }: { label?: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-ivory-100">
      <Spinner size={32} />
      {label && <p className="text-sm text-charcoal-400">{label}</p>}
    </div>
  );
}
