import type { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  hint: string;
  icon: LucideIcon;
  /** Number to show, or '—' when the figure isn't available yet. */
  value: number | string;
  index?: number;
}

export function StatCard({ label, hint, icon: Icon, value, index = 0 }: StatCardProps) {
  return (
    <div className="card animate-fade-in-up p-5" style={{ animationDelay: `${index * 80}ms` }}>
      <div className="flex items-center justify-between">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-beige-100 text-charcoal-500">
          <Icon size={18} />
        </div>
        <span className="font-serif text-3xl font-600 text-charcoal-700">{value}</span>
      </div>
      <p className="mt-3 text-sm font-500 text-charcoal-600">{label}</p>
      <p className="text-xs text-charcoal-400">{hint}</p>
    </div>
  );
}
