import { BRAND } from '@/config/brand';
import { cn } from '@/utils/cn';

interface LogoProps {
  className?: string;
  variant?: 'full' | 'mark';
  theme?: 'dark' | 'light';
}

export function Logo({ className, variant = 'full', theme = 'dark' }: LogoProps) {
  const textColor = theme === 'light' ? 'text-white' : 'text-charcoal-700';
  const accentColor = theme === 'light' ? 'text-terracotta-200' : 'text-terracotta-400';

  return (
    <span className={cn('inline-flex items-center gap-2 select-none', className)}>
      <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-terracotta-400 shadow-soft">
        <span className="font-serif text-lg font-700 text-white leading-none">K</span>
        <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-sage-400 ring-2 ring-ivory-100" />
      </span>
      {variant === 'full' && (
        <span className={cn('font-serif text-xl font-600 tracking-tight', textColor)}>
          {BRAND.name}
        </span>
      )}
      {variant === 'full' && (
        <span className={cn('hidden sm:inline text-xs font-500', accentColor)}>
          ·
        </span>
      )}
    </span>
  );
}
