import { Link } from 'react-router-dom';
import { Instagram, Twitter, Facebook, Mail, type LucideIcon } from 'lucide-react';
import { BRAND } from '@/config/brand';
import { Logo } from '@/components/ui/Logo';

export function Footer() {
  const year = new Date().getFullYear();

  // Social/legal URLs live in BRAND so there are no dead "#" links; unset ones are hidden.
  const socials: { Icon: LucideIcon; href: string; label: string }[] = [
    { Icon: Instagram, href: BRAND.social.instagram, label: 'Instagram' },
    { Icon: Twitter, href: BRAND.social.twitter, label: 'Twitter' },
    { Icon: Facebook, href: BRAND.social.facebook, label: 'Facebook' },
    { Icon: Mail, href: `mailto:${BRAND.supportEmail}`, label: 'Email us' },
  ].filter((s) => s.href);
  const legal = [
    { label: 'Privacy', href: BRAND.legal.privacy },
    { label: 'Terms', href: BRAND.legal.terms },
  ].filter((l) => l.href);

  const columns = [
    {
      title: 'Marketplace',
      links: [
        { label: 'Browse caterers', href: '/#browse' },
        { label: 'How it works', href: '/#how-it-works' },
        { label: 'Counties we serve', href: '/#counties' },
      ],
    },
    {
      title: 'For vendors',
      links: [
        { label: 'List your business', href: '/signup' },
        { label: 'Why join', href: '/#for-vendors' },
        { label: 'Sign in', href: '/signin' },
      ],
    },
    {
      title: 'Company',
      links: [
        { label: 'About', href: '/#about' },
        { label: 'Contact', href: `mailto:${BRAND.supportEmail}` },
      ],
    },
  ];

  return (
    <footer className="border-t border-beige-200 bg-ivory-200">
      <div className="mx-auto max-w-7xl px-5 py-12 sm:px-8 lg:px-12 lg:py-16">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4 lg:gap-12">
          <div className="col-span-2 md:col-span-1">
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-charcoal-400">
              {BRAND.tagline}. Connecting Kenya with exceptional catering for every occasion.
            </p>
            <div className="mt-5 flex gap-2">
              {socials.map(({ Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  {...(href.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-beige-300 text-charcoal-400 transition-colors hover:border-terracotta-300 hover:text-terracotta-400"
                  aria-label={label}
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="font-sans text-xs font-600 uppercase tracking-wider text-charcoal-500">
                {col.title}
              </h4>
              <ul className="mt-4 space-y-3">
                {col.links.map((link) => (
                  <li key={link.label}>
                    {link.href.startsWith('mailto:') ? (
                      <a
                        href={link.href}
                        className="text-sm text-charcoal-400 transition-colors hover:text-terracotta-400"
                      >
                        {link.label}
                      </a>
                    ) : (
                      <Link
                        to={link.href}
                        className="text-sm text-charcoal-400 transition-colors hover:text-terracotta-400"
                      >
                        {link.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-beige-300 pt-6 sm:flex-row">
          <p className="text-xs text-charcoal-400">
            © {year} {BRAND.name}. All rights reserved.
          </p>
          <div className="flex gap-6">
            {legal.map((l) => (
              <a key={l.label} href={l.href} className="text-xs text-charcoal-400 transition-colors hover:text-charcoal-600">
                {l.label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
