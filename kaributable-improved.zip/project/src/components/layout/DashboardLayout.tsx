import { useEffect, useState, type ReactNode } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Heart,
  MessageSquare,
  Calendar,
  Settings,
  LogOut,
  Menu,
  X,
  Home,
  type LucideIcon,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Logo } from '@/components/ui/Logo';
import { cn } from '@/utils/cn';
import type { UserRole } from '@/types';

interface NavItem {
  label: string;
  icon: LucideIcon;
  path: string;
  end?: boolean;
}

const ROLE_LABELS: Record<UserRole, string> = {
  customer: 'Customer',
  vendor: 'Vendor',
  admin: 'Administrator',
};

function navItemsFor(role: UserRole): NavItem[] {
  const base = `/${role}`;
  const roleItems: NavItem[] =
    role === 'customer'
      ? [
          { label: 'Saved vendors', icon: Heart, path: `${base}/saved` },
          { label: 'Messages', icon: MessageSquare, path: `${base}/messages` },
          { label: 'Bookings', icon: Calendar, path: `${base}/bookings` },
        ]
      : role === 'vendor'
        ? [
            { label: 'Enquiries', icon: MessageSquare, path: `${base}/enquiries` },
            { label: 'Bookings', icon: Calendar, path: `${base}/bookings` },
            { label: 'Profile', icon: Home, path: `${base}/profile` },
          ]
        : [];

  return [
    { label: 'Overview', icon: LayoutDashboard, path: base, end: true },
    ...roleItems,
    { label: 'Settings', icon: Settings, path: `${base}/settings` },
  ];
}

/** Shell for a role's dashboard. Renders nested routes via <Outlet /> unless children are given. */
export function DashboardLayout({ children, role }: { children?: ReactNode; role: UserRole }) {
  const { profile, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = navItemsFor(role);

  // Close the mobile drawer on navigation or Escape, and stop the page scrolling behind it.
  useEffect(() => setSidebarOpen(false), [location.pathname]);
  useEffect(() => {
    if (!sidebarOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setSidebarOpen(false);
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [sidebarOpen]);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const sidebar = (
    <SidebarContent profile={profile} navItems={navItems} roleLabel={ROLE_LABELS[role]} onSignOut={handleSignOut} />
  );

  return (
    <div className="min-h-screen bg-ivory-100">
      {/* Sidebar — desktop */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 border-r border-beige-200 bg-white lg:flex lg:flex-col">
        {sidebar}
      </aside>

      {/* Sidebar — mobile drawer */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation menu">
          <div className="absolute inset-0 bg-charcoal-900/40 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute inset-y-0 left-0 flex w-72 max-w-[85vw] animate-fade-in flex-col border-r border-beige-200 bg-white">
            <button
              className="absolute right-3 top-4 flex h-9 w-9 items-center justify-center rounded-lg text-charcoal-400 hover:bg-beige-100"
              onClick={() => setSidebarOpen(false)}
              aria-label="Close menu"
            >
              <X size={20} />
            </button>
            {sidebar}
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="lg:pl-64">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-beige-200 bg-white/90 px-5 backdrop-blur-md sm:px-8">
          <button
            className="flex h-10 w-10 items-center justify-center rounded-xl text-charcoal-600 hover:bg-beige-100 lg:hidden"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open menu"
            aria-expanded={sidebarOpen}
          >
            <Menu size={22} />
          </button>
          <div className="flex items-center gap-2 text-sm text-charcoal-400">
            <Link to="/" className="hover:text-charcoal-600">
              Home
            </Link>
            <span aria-hidden="true">/</span>
            <span className="font-500 capitalize text-charcoal-600">{role} dashboard</span>
          </div>
          <div className="ml-auto flex items-center gap-3">
            <span className="hidden text-sm text-charcoal-400 sm:inline">
              {profile?.full_name?.split(' ')[0] || 'Account'}
            </span>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-terracotta-100 text-sm font-600 text-terracotta-600">
              {(profile?.full_name || '?').charAt(0).toUpperCase()}
            </div>
          </div>
        </header>

        <main className="px-5 py-8 sm:px-8 lg:py-10">{children ?? <Outlet />}</main>
      </div>
    </div>
  );
}

function SidebarContent({
  profile,
  navItems,
  roleLabel,
  onSignOut,
}: {
  profile: { full_name: string; email: string } | null;
  navItems: NavItem[];
  roleLabel: string;
  onSignOut: () => void;
}) {
  return (
    <>
      <div className="flex h-16 items-center border-b border-beige-200 px-5">
        <Link to="/">
          <Logo />
        </Link>
      </div>

      <div className="border-b border-beige-200 px-5 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-terracotta-100 text-sm font-600 text-terracotta-600">
            {(profile?.full_name || '?').charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-600 text-charcoal-700">{profile?.full_name || 'Account'}</p>
            <p className="truncate text-xs text-charcoal-400">{roleLabel}</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4" aria-label="Dashboard">
        <p className="px-3 pb-2 text-[10px] font-600 uppercase tracking-wider text-charcoal-300">Menu</p>
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                end={item.end}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-500 transition-colors',
                    isActive
                      ? 'bg-terracotta-50 text-terracotta-600'
                      : 'text-charcoal-500 hover:bg-beige-100 hover:text-charcoal-700'
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    <item.icon size={18} className={isActive ? 'text-terracotta-400' : 'text-charcoal-400'} />
                    {item.label}
                  </>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <div className="border-t border-beige-200 p-3">
        <button
          onClick={onSignOut}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-500 text-error-500 transition-colors hover:bg-error-50"
        >
          <LogOut size={18} />
          Sign out
        </button>
      </div>
    </>
  );
}
