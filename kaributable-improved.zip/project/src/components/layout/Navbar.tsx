import { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, LogOut, LayoutDashboard, ChevronDown } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { BRAND } from '@/config/brand';
import { dashboardPathFor } from '@/types';
import { Logo } from '@/components/ui/Logo';
import { cn } from '@/utils/cn';

export function Navbar() {
  const { user, profile, role, signOut } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const menuRef = useRef<HTMLDivElement>(null);
  // Over the dark hero photo the bar needs light text; once scrolled (or the mobile
  // sheet is open) it sits on ivory and needs dark text.
  const onDark = !scrolled && !mobileOpen;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setMenuOpen(false);
  }, [location.pathname, location.hash]);

  useEffect(() => {
    if (!menuOpen) return;
    const onPointer = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setMenuOpen(false);
    document.addEventListener('mousedown', onPointer);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onPointer);
      document.removeEventListener('keydown', onKey);
    };
  }, [menuOpen]);

  const dashboardPath = role ? dashboardPathFor(role) : '/signin';

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const navLinks = [
    { label: 'How it works', href: '/#how-it-works' },
    { label: 'For vendors', href: '/#for-vendors' },
    { label: 'Counties', href: '/#counties' },
  ];

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-all duration-300 ease-smooth',
        scrolled
          ? 'border-b border-beige-200 bg-ivory-100/90 backdrop-blur-md shadow-soft'
          : 'border-b border-transparent bg-transparent'
      )}
    >
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-12">
        <Link to="/" className="transition-transform duration-200 hover:scale-[1.02]">
          <Logo theme={onDark ? 'light' : 'dark'} />
        </Link>

        {/* Desktop nav */}
        <div className="hidden items-center gap-1 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className={cn(
                'rounded-full px-4 py-2 text-sm font-500 transition-colors duration-200',
                onDark
                  ? 'text-white/85 hover:bg-white/10 hover:text-white'
                  : 'text-charcoal-500 hover:bg-beige-200 hover:text-charcoal-700'
              )}
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* Desktop auth */}
        <div className="hidden items-center gap-3 md:flex">
          {!user ? (
            <>
              <Link
                to="/signin"
                className={cn('btn-ghost', onDark && 'text-white hover:bg-white/10 hover:text-white')}
              >
                Sign in
              </Link>
              <Link to="/signup" className="btn-primary">
                Get started
              </Link>
            </>
          ) : (
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setMenuOpen((v) => !v)}
                aria-haspopup="menu"
                aria-expanded={menuOpen}
                className="flex items-center gap-2 rounded-full border border-beige-300 bg-white py-1.5 pl-1.5 pr-3 text-sm font-500 text-charcoal-700 transition-colors hover:border-charcoal-300"
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-terracotta-100 text-xs font-600 text-terracotta-600">
                  {(profile?.full_name || user.email || '?').charAt(0).toUpperCase()}
                </span>
                <span className="max-w-[120px] truncate">
                  {profile?.full_name?.split(' ')[0] || 'Account'}
                </span>
                <ChevronDown size={14} className={cn('transition-transform', menuOpen && 'rotate-180')} />
              </button>

              {menuOpen && (
                <div className="absolute right-0 top-full mt-2 w-56 origin-top-right rounded-2xl border border-beige-200 bg-white p-2 shadow-lifted animate-scale-in">
                  <div className="px-3 py-2 border-b border-beige-200 mb-1">
                    <p className="text-xs text-charcoal-400">Signed in as</p>
                    <p className="text-sm font-500 text-charcoal-700 truncate">{profile?.email || user.email}</p>
                    {role && (
                      <span className="mt-1 inline-block badge bg-sage-100 text-sage-700 capitalize">
                        {role}
                      </span>
                    )}
                  </div>
                  <Link
                    to={dashboardPath}
                    className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-charcoal-600 transition-colors hover:bg-beige-100"
                  >
                    <LayoutDashboard size={16} />
                    Dashboard
                  </Link>
                  <button
                    onClick={handleSignOut}
                    className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-error-500 transition-colors hover:bg-error-50"
                  >
                    <LogOut size={16} />
                    Sign out
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Mobile toggle */}
        <button
          className={cn(
            'flex h-10 w-10 items-center justify-center rounded-xl transition-colors md:hidden',
            onDark ? 'text-white hover:bg-white/10' : 'text-charcoal-600 hover:bg-beige-200'
          )}
          onClick={() => setMobileOpen((v) => !v)}
          aria-label="Toggle menu"
          aria-expanded={mobileOpen}
        >
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="border-t border-beige-200 bg-ivory-100 px-5 py-4 md:hidden animate-fade-in">
          <div className="flex flex-col gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className="rounded-xl px-4 py-3 text-sm font-500 text-charcoal-600 transition-colors hover:bg-beige-200"
              >
                {link.label}
              </Link>
            ))}
            <div className="my-2 h-px bg-beige-200" />
            {!user ? (
              <>
                <Link to="/signin" className="btn-secondary w-full justify-center">
                  Sign in
                </Link>
                <Link to="/signup" className="btn-primary w-full justify-center">
                  Get started
                </Link>
              </>
            ) : (
              <>
                <Link
                  to={dashboardPath}
                  className="flex items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-500 text-charcoal-600 hover:bg-beige-200"
                >
                  <LayoutDashboard size={18} />
                  Dashboard
                </Link>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-500 text-error-500 hover:bg-error-50"
                >
                  <LogOut size={18} />
                  Sign out
                </button>
                <p className="px-4 pt-2 text-xs text-charcoal-400">{BRAND.name} · {role}</p>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
