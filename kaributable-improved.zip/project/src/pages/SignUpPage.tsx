import { useState, type FormEvent } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { Mail, Lock, User, Phone, ArrowRight, AlertCircle, Check, MailCheck } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { isValidKenyanPhone, normalizeKenyanPhone } from '@/utils/phone';
import { supabase } from '@/lib/supabase';
import { BRAND } from '@/config/brand';
import { Logo } from '@/components/ui/Logo';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { cn } from '@/utils/cn';
import type { SignUpRole } from '@/types';

export function SignUpPage() {
  const { user, loading: authLoading } = useAuth();

  const [role, setRole] = useState<SignUpRole>('customer');
  const [needsConfirmation, setNeedsConfirmation] = useState(false);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const roles: { value: SignUpRole; label: string; desc: string }[] = [
    { value: 'customer', label: "I'm planning an event", desc: 'Find and book caterers' },
    { value: 'vendor', label: "I'm a caterer or chef", desc: 'List your business' },
  ];

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!fullName.trim()) {
      setError('Please enter your full name.');
      return;
    }

    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }

    if (phone && !isValidKenyanPhone(phone)) {
      setError('Please enter a valid Kenyan phone number (e.g. 0712 345 678 or +254712345678).');
      return;
    }

    const normalizedPhone = normalizeKenyanPhone(phone) || null;

    setLoading(true);

    // Only 'customer' or 'vendor' are ever sent. 'admin' is never an option here.
    const { data, error: signUpError } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        data: {
          user_role: role,
          full_name: fullName.trim(),
          phone: normalizedPhone,
        },
      },
    });

    if (signUpError) {
      setError(
        signUpError.message.includes('already registered')
          ? 'An account with this email already exists. Try signing in instead.'
          : signUpError.message
      );
      setLoading(false);
      return;
    }

    if (data.session) {
      // Signed in immediately. Create the profile row now (the DB trigger sets `role`);
      // if this fails AuthContext creates it on load, so it is not fatal.
      const { error: profileError } = await supabase.from('profiles').upsert(
        {
          id: data.session.user.id,
          email: email.trim(),
          full_name: fullName.trim(),
          phone: normalizedPhone,
        },
        { onConflict: 'id', ignoreDuplicates: true }
      );
      if (profileError) console.warn('Profile insert warning:', profileError.message);
      // The redirect below takes over once AuthContext has the session.
      return;
    }

    // Email confirmation is on: no session yet. The profile is created on first sign-in.
    setNeedsConfirmation(true);
    setLoading(false);
  };

  if (user && !authLoading) return <Navigate to="/profile-setup" replace />;

  if (needsConfirmation) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ivory-100 px-5 py-12">
        <div className="w-full max-w-md text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-sage-100 text-sage-600">
            <MailCheck size={26} />
          </div>
          <h1 className="mt-6 font-serif text-3xl font-600 text-charcoal-700">Check your email</h1>
          <p className="mt-3 text-sm leading-relaxed text-charcoal-400">
            We sent a confirmation link to <span className="font-500 text-charcoal-600">{email.trim()}</span>.
            Open it to activate your account, then sign in.
          </p>
          <Link to="/signin" className="btn-primary mt-8">
            Go to sign in
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      {/* Left panel — image */}
      <div className="relative hidden lg:block lg:w-1/2">
        <img
          src="https://images.pexels.com/photos/17294719/pexels-photo-17294719.jpeg?auto=compress&cs=tinysrgb&w=1200"
          alt="Catering buffet spread"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-charcoal-900/50 to-charcoal-900/20" />
        <div className="absolute bottom-0 left-0 right-0 p-12">
          <Logo theme="light" />
          <p className="mt-4 max-w-sm font-serif text-2xl font-500 text-white leading-snug">
            Where Kenya finds its caterers.
          </p>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 overflow-y-auto bg-ivory-100 px-5 py-12 sm:px-8">
        <div className="mx-auto w-full max-w-md">
          <div className="lg:hidden">
            <Link to="/">
              <Logo />
            </Link>
          </div>

          <h1 className="mt-8 font-serif text-3xl font-600 text-charcoal-700 lg:mt-0">
            Create your account
          </h1>
          <p className="mt-2 text-sm text-charcoal-400">
            Join {BRAND.name} — free during launch.
          </p>

          {/* Role selection */}
          <div className="mt-6">
            <label className="block text-sm font-500 text-charcoal-600">
              I want to...
            </label>
            <div className="mt-2 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {roles.map((r) => (
                <button
                  key={r.value}
                  type="button"
                  onClick={() => setRole(r.value)}
                  className={cn(
                    'relative rounded-xl border p-4 text-left transition-all duration-200',
                    role === r.value
                      ? 'border-terracotta-400 bg-terracotta-50 shadow-soft'
                      : 'border-beige-300 bg-white hover:border-charcoal-300'
                  )}
                >
                  {role === r.value && (
                    <span className="absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-full bg-terracotta-400 text-white">
                      <Check size={12} />
                    </span>
                  )}
                  <p className="text-sm font-600 text-charcoal-700">{r.label}</p>
                  <p className="mt-0.5 text-xs text-charcoal-400">{r.desc}</p>
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            {error && (
              <div className="flex items-start gap-2.5 rounded-xl border border-error-100 bg-error-50 px-4 py-3 text-sm text-error-600">
                <AlertCircle size={18} className="mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <Input
              label="Full name"
              type="text"
              name="fullName"
              placeholder="Jane Wanjiru"
              icon={<User size={18} />}
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              required
              autoComplete="name"
            />

            <Input
              label="Email"
              type="email"
              name="email"
              placeholder="you@example.com"
              icon={<Mail size={18} />}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />

            <Input
              label="Phone number"
              type="tel"
              name="phone"
              placeholder="+254712345678"
              icon={<Phone size={18} />}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              onBlur={() => setPhone(normalizeKenyanPhone(phone))}
              hint="Optional. e.g. 0712 345 678 — saved as +254712345678"
            />

            <Input
              label="Password"
              type="password"
              name="password"
              placeholder="At least 8 characters"
              icon={<Lock size={18} />}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="new-password"
            />

            <Button type="submit" loading={loading} className="w-full justify-center" size="lg">
              Create account
              <ArrowRight size={16} />
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-charcoal-400">
            Already have an account?{' '}
            <Link to="/signin" className="font-500 text-terracotta-400 hover:text-terracotta-500">
              Sign in
            </Link>
          </p>

          <p className="mt-6 text-center text-xs leading-relaxed text-charcoal-300">
            By creating an account, you agree to {BRAND.name}'s Terms of Service and Privacy Policy.
          </p>
        </div>
      </div>
    </div>
  );
}
