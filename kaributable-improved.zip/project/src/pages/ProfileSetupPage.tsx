import { useState, useEffect, type FormEvent } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { User, Phone, ArrowRight, Check, AlertCircle, Camera } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { isValidKenyanPhone, normalizeKenyanPhone } from '@/utils/phone';
import { dashboardPathFor } from '@/types';
import { Logo } from '@/components/ui/Logo';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { cn } from '@/utils/cn';

export function ProfileSetupPage() {
  const { user, profile, role, refreshProfile } = useAuth();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setPhone(profile.phone || '');
    }
  }, [profile]);

  const steps = [
    { label: 'Account created', done: true },
    { label: 'Complete your profile', done: false },
    { label: 'Start exploring', done: false },
  ];

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!user) {
      setError('No active session. Please sign in again.');
      return;
    }

    if (!fullName.trim()) {
      setError('Please enter your full name.');
      return;
    }
    if (phone && !isValidKenyanPhone(phone)) {
      setError('Please enter a valid Kenyan phone number (e.g. 0712 345 678).');
      return;
    }

    setSaving(true);

    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        full_name: fullName.trim(),
        phone: normalizeKenyanPhone(phone) || null,
        onboarding_complete: true,
      })
      .eq('id', user.id);

    if (updateError) {
      setError(updateError.message);
      setSaving(false);
      return;
    }

    await refreshProfile();

    navigate(dashboardPathFor(role ?? 'customer'), { replace: true });
  };

  // ProtectedRoute guarantees a signed-in user with a profile; this narrows the types.
  if (!user) return null;
  // Already onboarded (e.g. revisiting the URL): go to the dashboard.
  if (profile?.onboarding_complete && !saving) {
    return <Navigate to={dashboardPathFor(role ?? 'customer')} replace />;
  }

  const roleLabel = role === 'vendor' ? 'vendor' : 'customer';

  return (
    <div className="min-h-screen bg-ivory-100">
      <div className="mx-auto max-w-2xl px-5 py-12 sm:px-8 lg:py-20">
        <Link to="/" className="inline-block">
          <Logo />
        </Link>

        {/* Progress */}
        <div className="mt-8 flex items-center gap-2">
          {steps.map((step, i) => (
            <div key={step.label} className="flex flex-1 items-center gap-2">
              <div className="flex items-center gap-2">
                <span
                  className={cn(
                    'flex h-7 w-7 items-center justify-center rounded-full text-xs font-600',
                    step.done
                      ? 'bg-sage-400 text-white'
                      : i === 1
                        ? 'bg-terracotta-400 text-white'
                        : 'bg-beige-300 text-charcoal-400'
                  )}
                >
                  {step.done ? <Check size={14} /> : i + 1}
                </span>
                <span className={cn('text-xs font-500', step.done ? 'text-sage-700' : 'text-charcoal-500')}>
                  {step.label}
                </span>
              </div>
              {i < steps.length - 1 && <div className="h-px flex-1 bg-beige-300" />}
            </div>
          ))}
        </div>

        <div className="mt-10">
          <span className="badge bg-sage-100 text-sage-700 capitalize">
            {roleLabel} account
          </span>
          <h1 className="mt-3 font-serif text-3xl font-600 text-charcoal-700">
            {role === 'vendor' ? 'Set up your vendor profile' : 'Complete your profile'}
          </h1>
          <p className="mt-2 text-sm text-charcoal-400">
            {role === 'vendor'
              ? 'Let customers know who you are. You can add menus, packages, and photos next.'
              : 'Tell us a bit about yourself so we can personalise your experience.'}
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-5">
            {error && (
              <div className="flex items-start gap-2.5 rounded-xl border border-error-100 bg-error-50 px-4 py-3 text-sm text-error-600">
                <AlertCircle size={18} className="mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Avatar placeholder */}
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-terracotta-100 text-xl font-600 text-terracotta-500">
                {(fullName || user.email || '?').charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="text-sm font-500 text-charcoal-600">Profile photo</p>
                <p className="text-xs text-charcoal-400">Photo upload available in Phase 2</p>
              </div>
              <button
                type="button"
                disabled
                className="ml-auto flex h-9 w-9 cursor-not-allowed items-center justify-center rounded-full border border-beige-300 text-charcoal-300"
              >
                <Camera size={16} />
              </button>
            </div>

            <Input
              label="Full name"
              type="text"
              name="fullName"
              autoComplete="name"
              icon={<User size={18} />}
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              required
            />

            <Input
              label="Email"
              type="email"
              name="email"
              value={user.email || ''}
              disabled
              hint="Email is managed through your account settings."
              className="bg-ivory-200/60"
            />

            <Input
              label="Phone number"
              type="tel"
              name="phone"
              placeholder="+254712345678"
              icon={<Phone size={18} />}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              onBlur={() => setPhone(normalizeKenyanPhone(phone))}
              hint="Optional. e.g. 0712 345 678 — saved as +254712345678"
            />

            {role === 'vendor' && (
              <div className="rounded-xl border border-sage-200 bg-sage-50 p-4">
                <p className="text-sm font-500 text-sage-700">What's next?</p>
                <p className="mt-1 text-xs leading-relaxed text-sage-600">
                  After this step, your vendor dashboard will be ready. In Phase 2, you'll be able to
                  add your business name, photos, menus, packages, service areas, and availability.
                </p>
              </div>
            )}

            <Button type="submit" loading={saving} className="w-full justify-center" size="lg">
              {role === 'vendor' ? 'Continue to dashboard' : 'Start exploring'}
              <ArrowRight size={16} />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
