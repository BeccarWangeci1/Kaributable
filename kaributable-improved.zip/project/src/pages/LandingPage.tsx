import { Link } from 'react-router-dom';
import {
  Search,
  MapPin,
  Users,
  Calendar,
  Sparkles,
  ShieldCheck,
  Heart,
  ChefHat,
  UtensilsCrossed,
  Home,
  Building2,
  ArrowRight,
  Quote,
  Star,
} from 'lucide-react';
import { BRAND } from '@/config/brand';

const HERO_IMAGE =
  'https://images.pexels.com/photos/17294719/pexels-photo-17294719.jpeg?auto=compress&cs=tinysrgb&w=1600';

const CUISINE_IMAGES = {
  buffet:
    'https://images.pexels.com/photos/29486068/pexels-photo-29486068.jpeg?auto=compress&cs=tinysrgb&w=800',
  kenyan:
    'https://images.pexels.com/photos/37100094/pexels-photo-37100094.jpeg?auto=compress&cs=tinysrgb&w=800',
  chef:
    'https://images.pexels.com/photos/30892994/pexels-photo-30892994.jpeg?auto=compress&cs=tinysrgb&w=800',
  wedding:
    'https://images.pexels.com/photos/29040997/pexels-photo-29040997.jpeg?auto=compress&cs=tinysrgb&w=800',
  catering:
    'https://images.pexels.com/photos/28736731/pexels-photo-28736731.jpeg?auto=compress&cs=tinysrgb&w=800',
  appetizers:
    'https://images.pexels.com/photos/11066891/pexels-photo-11066891.jpeg?auto=compress&cs=tinysrgb&w=800',
};

const VENDOR_TYPES = [
  { icon: Building2, label: 'Catering companies', desc: 'Established, full-service teams' },
  { icon: UtensilsCrossed, label: 'Independent caterers', desc: 'Boutique, specialised businesses' },
  { icon: Home, label: 'Home-based caterers', desc: 'Authentic, home-cooked quality' },
  { icon: ChefHat, label: 'Private chefs', desc: 'Personalised, in-venue cooking' },
];

const FEATURES = [
  {
    icon: Search,
    title: 'Search with intent',
    desc: 'Filter by county, event type, guest count, date, and budget — find caterers who actually match your needs.',
  },
  {
    icon: Quote,
    title: 'Request tailored quotes',
    desc: 'Send your event brief to up to three vendors and compare customised quotations side by side.',
  },
  {
    icon: ShieldCheck,
    title: 'Verified & reviewed',
    desc: 'Every vendor is reviewed by real customers. Verified vendors carry a badge you can trust.',
  },
  {
    icon: Heart,
    title: 'Save your favourites',
    desc: 'Bookmark caterers you love and come back to them when the right occasion arrives.',
  },
];

const STEPS = [
  {
    num: '01',
    title: 'Tell us about your event',
    desc: 'Share your date, location, guest count, and what you are celebrating. It takes less than a minute.',
  },
  {
    num: '02',
    title: 'Compare curated caterers',
    desc: 'Browse vendor profiles, menus, packages, and reviews. Send your brief to up to three favourites.',
  },
  {
    num: '03',
    title: 'Receive your quotations',
    desc: 'Vendors respond with tailored quotes. Compare prices, packages, and terms — all in one place.',
  },
  {
    num: '04',
    title: 'Book with confidence',
    desc: 'Accept the quote that fits and confirm your booking. Message your caterer directly through the platform.',
  },
];

const COUNTIES = [
  'Nairobi', 'Kiambu', 'Mombasa', 'Nakuru', 'Kisumu', 'Kakamega', 'Nyeri', 'Eldoret (Uasin Gishu)',
  'Machakos', 'Kilifi', 'Meru', 'Kisii', 'Bungoma', 'Garissa', 'Kericho',
];

export function LandingPage() {
  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="relative min-h-[100svh] flex items-center pt-16">
        <div className="absolute inset-0">
          <img
            src={HERO_IMAGE}
            alt="Elegant catering spread"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-900/60 via-charcoal-900/40 to-ivory-100" />
          <div className="absolute inset-0 bg-gradient-to-r from-charcoal-900/50 to-transparent" />
        </div>

        <div className="relative mx-auto max-w-7xl px-5 sm:px-8 lg:px-12 py-20">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-500 text-white backdrop-blur-sm animate-fade-in">
              <Sparkles size={13} className="text-terracotta-200" />
              Now serving all 47 counties in Kenya
            </span>

            <h1 className="mt-6 text-display-xl font-serif font-600 text-white text-balance animate-fade-in-up">
              Exceptional catering,<br />
              <span className="text-terracotta-200">for every occasion.</span>
            </h1>

            <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/85 animate-fade-in-up animation-delay-200">
              {BRAND.name} connects you with Kenya's finest caterers, private chefs, and home-based
              cooks — from intimate gatherings to grand celebrations.
            </p>

            {/* Search bar */}
            <div className="mt-10 max-w-2xl animate-fade-in-up animation-delay-300">
              <div className="rounded-2xl border border-white/20 bg-white/95 p-2 shadow-lifted backdrop-blur-md">
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_1fr_auto]">
                  <div className="relative">
                    <MapPin size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal-300" />
                    <input
                      type="text"
                      placeholder="County or town"
                      aria-label="County or town"
                      className="w-full rounded-xl border-0 bg-ivory-100 px-9 py-3 text-sm text-charcoal-700 placeholder:text-charcoal-400 focus:outline-none focus:ring-2 focus:ring-terracotta-200"
                    />
                  </div>
                  <div className="relative">
                    <Users size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal-300" />
                    <input
                      type="text"
                      placeholder="Guests"
                      aria-label="Number of guests"
                      className="w-full rounded-xl border-0 bg-ivory-100 px-9 py-3 text-sm text-charcoal-700 placeholder:text-charcoal-400 focus:outline-none focus:ring-2 focus:ring-terracotta-200"
                    />
                  </div>
                  <Link
                    to="/signup"
                    className="btn-primary justify-center whitespace-nowrap"
                  >
                    <Search size={16} />
                    Find caterers
                  </Link>
                </div>
              </div>
              <p className="mt-3 text-xs text-white/70">
                Free to browse. No obligation to book.
              </p>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 lg:flex">
          <span className="text-[10px] uppercase tracking-widest text-white/60">Scroll</span>
          <div className="flex h-10 w-6 justify-center rounded-full border border-white/30 pt-2">
            <span className="h-2 w-1 animate-bounce rounded-full bg-white/60" />
          </div>
        </div>
      </section>

      {/* Vendor types */}
      <section className="bg-ivory-100 py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-600 uppercase tracking-wider text-terracotta-400">
              One marketplace, every kind of caterer
            </p>
            <h2 className="mt-3 text-display-md font-serif font-600 text-charcoal-700 text-balance">
              Find the right match for your event
            </h2>
            <p className="mt-4 text-charcoal-400 leading-relaxed">
              From established catering companies to passionate home-based cooks, every vendor on{' '}
              {BRAND.name} is here to make your occasion memorable.
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {VENDOR_TYPES.map((type, i) => (
              <div
                key={type.label}
                className="card p-6 hover:shadow-card-hover hover:-translate-y-1 animate-fade-in-up"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-terracotta-50 text-terracotta-400">
                  <type.icon size={22} />
                </div>
                <h3 className="mt-4 font-serif text-lg font-600 text-charcoal-700">{type.label}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-charcoal-400">{type.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pinterest-inspired food grid */}
      <section id="browse" className="scroll-mt-16 bg-ivory-200 py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
          <div className="flex flex-col items-end justify-between gap-6 sm:flex-row">
            <div className="max-w-xl">
              <p className="text-sm font-600 uppercase tracking-wider text-sage-500">
                A taste of what's possible
              </p>
              <h2 className="mt-3 text-display-md font-serif font-600 text-charcoal-700">
                Food worth celebrating
              </h2>
            </div>
            <p className="max-w-md text-sm leading-relaxed text-charcoal-400">
              Browse menus, packages, and portfolios from vendors across Kenya. Every caterer brings
              something uniquely theirs to the table.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4 lg:gap-5">
            {/* Masonry-style varied heights */}
            <div className="space-y-4 lg:space-y-5">
              <FoodCard image={CUISINE_IMAGES.buffet} label="Gourmet buffets" height="tall" />
              <FoodCard image={CUISINE_IMAGES.appetizers} label="Canapés & appetizers" height="short" />
            </div>
            <div className="space-y-4 lg:space-y-5 pt-8 lg:pt-16">
              <FoodCard image={CUISINE_IMAGES.kenyan} label="Authentic Kenyan cuisine" height="short" />
              <FoodCard image={CUISINE_IMAGES.wedding} label="Wedding receptions" height="tall" />
            </div>
            <div className="space-y-4 lg:space-y-5">
              <FoodCard image={CUISINE_IMAGES.chef} label="Private chef experiences" height="tall" />
              <FoodCard image={CUISINE_IMAGES.catering} label="Event catering" height="short" />
            </div>
            <div className="space-y-4 lg:space-y-5 pt-8 lg:pt-16">
              <FoodCard image={CUISINE_IMAGES.appetizers} label="Plated dinners" height="short" />
              <FoodCard image={CUISINE_IMAGES.buffet} label="Corporate events" height="tall" />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="how-it-works" className="scroll-mt-16 bg-white py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-600 uppercase tracking-wider text-terracotta-400">
              Why {BRAND.name}
            </p>
            <h2 className="mt-3 text-display-md font-serif font-600 text-charcoal-700 text-balance">
              Designed for the way Kenyans celebrate
            </h2>
          </div>

          <div className="mt-14 grid grid-cols-1 gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((feature, i) => (
              <div key={feature.title} className="animate-fade-in-up" style={{ animationDelay: `${i * 100}ms` }}>
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sage-50 text-sage-500">
                  <feature.icon size={20} />
                </div>
                <h3 className="mt-5 font-serif text-lg font-600 text-charcoal-700">{feature.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-charcoal-400">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="bg-ivory-100 py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-600 uppercase tracking-wider text-sage-500">
              Simple from start to finish
            </p>
            <h2 className="mt-3 text-display-md font-serif font-600 text-charcoal-700 text-balance">
              How {BRAND.name} works
            </h2>
          </div>

          <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((step, i) => (
              <div key={step.num} className="relative animate-fade-in-up" style={{ animationDelay: `${i * 100}ms` }}>
                {i < STEPS.length - 1 && (
                  <div className="absolute top-6 left-[60%] hidden h-px w-[80%] bg-gradient-to-r from-beige-300 to-transparent lg:block" />
                )}
                <div className="relative">
                  <span className="font-serif text-4xl font-600 text-terracotta-200">{step.num}</span>
                  <div className="mt-4 h-px w-12 bg-terracotta-300" />
                  <h3 className="mt-4 font-serif text-lg font-600 text-charcoal-700">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-charcoal-400">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-14 flex justify-center">
            <Link to="/signup" className="btn-primary">
              Get started — it's free
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* For vendors CTA */}
      <section id="for-vendors" className="scroll-mt-16 relative overflow-hidden bg-charcoal-700 py-20 lg:py-28">
        <div className="absolute inset-0 opacity-10">
          <img
            src={CUISINE_IMAGES.catering}
            alt=""
            className="h-full w-full object-cover"
          />
        </div>
        <div className="relative mx-auto max-w-4xl px-5 text-center sm:px-8 lg:px-12">
          <p className="text-sm font-600 uppercase tracking-wider text-terracotta-200">
            For caterers and chefs
          </p>
          <h2 className="mt-3 text-display-md font-serif font-600 text-white text-balance">
            Grow your catering business across Kenya
          </h2>
          <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-white/70">
            Join {BRAND.name} during launch and list your business for free. Reach customers planning
            events in your county, manage enquiries in one place, and build your reputation with reviews.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/signup" className="btn-primary">
              List your business
              <ArrowRight size={16} />
            </Link>
            <a href="#how-it-works" className="btn-secondary border-white/20 text-white hover:border-white/40 hover:bg-white/10">
              Learn more
            </a>
          </div>
          <div className="mt-12 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
            {[
              { icon: ShieldCheck, label: 'Free during launch' },
              { icon: Users, label: 'Reach 47 counties' },
              { icon: Star, label: 'Build your reputation' },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-2 text-sm text-white/60">
                <item.icon size={16} className="text-sage-300" />
                {item.label}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Counties */}
      <section id="counties" className="scroll-mt-16 bg-ivory-100 py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-600 uppercase tracking-wider text-sage-500">
              Nationwide coverage
            </p>
            <h2 className="mt-3 text-display-md font-serif font-600 text-charcoal-700 text-balance">
              Caterers in every corner of Kenya
            </h2>
            <p className="mt-4 text-charcoal-400 leading-relaxed">
              From Nairobi to Mandera, Mombasa to Busia — {BRAND.name} connects you with caterers
              serving all 47 counties.
            </p>
          </div>

          <div className="mt-12 flex flex-wrap justify-center gap-2.5">
            {COUNTIES.map((county, i) => (
              <span
                key={county}
                className="rounded-full border border-beige-300 bg-white px-4 py-2 text-sm text-charcoal-500 transition-colors hover:border-terracotta-300 hover:text-terracotta-500 cursor-default animate-fade-in"
                style={{ animationDelay: `${i * 30}ms` }}
              >
                <MapPin size={12} className="mr-1.5 inline -mt-0.5 text-terracotta-300" />
                {county}
              </span>
            ))}
            <span className="rounded-full bg-sage-100 px-4 py-2 text-sm font-500 text-sage-700">
              + 32 more counties
            </span>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section id="about" className="scroll-mt-16 bg-terracotta-50 py-20 lg:py-28">
        <div className="mx-auto max-w-3xl px-5 text-center sm:px-8 lg:px-12">
          <Calendar size={32} className="mx-auto text-terracotta-400" />
          <h2 className="mt-6 text-display-md font-serif font-600 text-charcoal-700 text-balance">
            Your next event deserves the right caterer
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-lg leading-relaxed text-charcoal-500">
            Join {BRAND.name} today. Whether you're planning a wedding in Nakuru or a corporate lunch
            in Westlands, your perfect caterer is here.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/signup" className="btn-primary">
              Create your account
              <ArrowRight size={16} />
            </Link>
            <Link to="/signin" className="btn-secondary">
              Sign in
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

function FoodCard({
  image,
  label,
  height,
}: {
  image: string;
  label: string;
  height: 'tall' | 'short';
}) {
  return (
    <div
      className={`group relative overflow-hidden rounded-2xl shadow-card transition-all duration-500 ease-smooth hover:shadow-lifted ${
        height === 'tall' ? 'aspect-[3/4]' : 'aspect-[4/3]'
      }`}
    >
      <img
        src={image}
        alt={label}
        className="h-full w-full object-cover transition-transform duration-700 ease-smooth group-hover:scale-105"
        loading="lazy"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/70 via-transparent to-transparent opacity-80 transition-opacity duration-300 group-hover:opacity-90" />
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <p className="font-serif text-base font-600 text-white translate-y-1 transition-transform duration-300 group-hover:translate-y-0">
          {label}
        </p>
      </div>
    </div>
  );
}
