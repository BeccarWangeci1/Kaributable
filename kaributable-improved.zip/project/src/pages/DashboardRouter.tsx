import { Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { dashboardPathFor } from '@/types';

/**
 * Redirects an authenticated user to their role-appropriate dashboard.
 * Rendered inside ProtectedRoute, so the role is always resolved by now.
 */
export function DashboardRouter() {
  const { role } = useAuth();
  return <Navigate to={role ? dashboardPathFor(role) : '/signin'} replace />;
}
