import { Link } from 'react-router-dom';
import { Heart, MessageSquare, Calendar, Search, ArrowRight, Sparkles } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { BRAND } from '@/config/brand';
import { StatCard } from '@/components/ui/StatCard';

export function CustomerDashboard() {
  const { profile } = useAuth();
  const firstName = profile?.full_name?.split(' ')[0] || 'there';

  const stats = [
    { label: 'Saved vendors', value: 0, icon: Heart, hint: 'Caterers you have bookmarked' },
    { label: 'Active enquiries', value: 0, icon: MessageSquare, hint: 'Quotation requests in progress' },
    { label: 'Upcoming bookings', value: 0, icon: Calendar, hint: 'Confirmed events ahead' },
  ];

  return (
    <>
      <div className="mx-auto max-w-5xl">
        {/* Greeting */}
        <div className="animate-fade-in">
          <h1 className="font-serif text-3xl font-600 text-charcoal-700">
            Karibu, {firstName}.
          </h1>
          <p className="mt-2 text-sm text-charcoal-400">
            Your {BRAND.name} dashboard — manage your enquiries, bookings, and saved caterers.
          </p>
        </div>

        {/* Coming soon banner */}
        <div className="mt-8 rounded-2xl border border-terracotta-200 bg-terracotta-50 p-6 animate-fade-in-up">
          <div className="flex items-start gap-4">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-terracotta-400 text-white">
              <Sparkles size={20} />
            </div>
            <div>
              <h2 className="font-serif text-lg font-600 text-charcoal-700">
                Marketplace is coming soon
              </h2>
              <p className="mt-1 text-sm leading-relaxed text-charcoal-500">
                Browse, compare, and book caterers across all 47 counties. Quotation requests,
                instant bookings, and in-app messaging will be available in Phase 2.
              </p>
              <Link
                to="/"
                className="mt-3 inline-flex items-center gap-1.5 text-sm font-500 text-terracotta-500 hover:text-terracotta-600"
              >
                Explore the homepage
                <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {stats.map((stat, i) => (
            <StatCard key={stat.label} {...stat} index={i} />
          ))}
        </div>

        {/* Quick actions */}
        <div className="mt-8">
          <h2 className="font-serif text-xl font-600 text-charcoal-700">Quick actions</h2>
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Link
              to="/#browse"
              className="card flex items-center gap-4 p-5 hover:shadow-card-hover hover:-translate-y-0.5 transition-all"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-terracotta-50 text-terracotta-400">
                <Search size={20} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-600 text-charcoal-700">Browse caterers</p>
                <p className="text-xs text-charcoal-400">Available in Phase 2</p>
              </div>
              <ArrowRight size={16} className="text-charcoal-300" />
            </Link>
            <Link
              to="/customer/saved"
              className="card flex items-center gap-4 p-5 hover:shadow-card-hover hover:-translate-y-0.5 transition-all"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sage-50 text-sage-500">
                <Heart size={20} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-600 text-charcoal-700">Saved vendors</p>
                <p className="text-xs text-charcoal-400">Your bookmarked caterers</p>
              </div>
              <ArrowRight size={16} className="text-charcoal-300" />
            </Link>
          </div>
        </div>

        {/* Profile card */}
        <div className="mt-8 card p-6">
          <h2 className="font-serif text-lg font-600 text-charcoal-700">Your profile</h2>
          <div className="mt-4 flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-terracotta-100 text-lg font-600 text-terracotta-600">
              {(profile?.full_name || '?').charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="font-500 text-charcoal-700">{profile?.full_name || 'Account'}</p>
              <p className="text-sm text-charcoal-400">{profile?.email}</p>
              {profile?.phone && <p className="text-sm text-charcoal-400">{profile.phone}</p>}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
