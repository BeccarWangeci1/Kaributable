import { Sparkles } from 'lucide-react';

interface ComingSoonProps {
  title: string;
  description: string;
}

export function ComingSoonPage({ title, description }: ComingSoonProps) {
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-serif text-2xl font-600 text-charcoal-700">{title}</h1>
      <p className="mt-2 text-sm text-charcoal-400">{description}</p>

      <div className="mt-8 rounded-2xl border border-terracotta-200 bg-terracotta-50 p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-terracotta-400 text-white">
          <Sparkles size={26} />
        </div>
        <h2 className="mt-4 font-serif text-xl font-600 text-charcoal-700">Available in Phase 2</h2>
        <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-charcoal-500">
          This section is part of the marketplace core, which arrives in the next development phase.
        </p>
      </div>
    </div>
  );
}
