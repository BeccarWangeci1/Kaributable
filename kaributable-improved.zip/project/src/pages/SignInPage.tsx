import { useState, type FormEvent } from 'react';
import { Link, Navigate, useLocation } from 'react-router-dom';
import { Mail, Lock, ArrowRight, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { BRAND } from '@/config/brand';
import { Logo } from '@/components/ui/Logo';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';

export function SignInPage() {
  const { user, loading: authLoading } = useAuth();
  const location = useLocation();
  const from = (location.state as { from?: string } | null)?.from;

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });

    if (signInError) {
      setError(
        signInError.message.includes('Invalid login credentials')
          ? 'Incorrect email or password. Please try again.'
          : signInError.message
      );
      setLoading(false);
      return;
    }

    // On success AuthContext picks up the session, and the redirect below fires once
    // the profile has resolved, so there is no navigate-before-ready race.
  };

  if (user && !authLoading) {
    return <Navigate to={from && from.startsWith('/') ? from : '/dashboard-router'} replace />;
  }

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      {/* Left panel — image */}
      <div className="relative hidden lg:block lg:w-1/2">
        <img
          src="https://images.pexels.com/photos/29040997/pexels-photo-29040997.jpeg?auto=compress&cs=tinysrgb&w=1200"
          alt="Elegant event table setting"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-charcoal-900/50 to-charcoal-900/20" />
        <div className="absolute bottom-0 left-0 right-0 p-12">
          <Logo theme="light" />
          <p className="mt-4 max-w-sm font-serif text-2xl font-500 text-white leading-snug">
            Welcome back. Your table is waiting.
          </p>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex flex-1 items-center justify-center bg-ivory-100 px-5 py-12 sm:px-8">
        <div className="w-full max-w-md">
          <div className="lg:hidden">
            <Link to="/">
              <Logo />
            </Link>
          </div>

          <h1 className="mt-8 font-serif text-3xl font-600 text-charcoal-700 lg:mt-0">
            Sign in to {BRAND.name}
          </h1>
          <p className="mt-2 text-sm text-charcoal-400">
            Welcome back. Enter your details to continue.
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-5">
            {error && (
              <div className="flex items-start gap-2.5 rounded-xl border border-error-100 bg-error-50 px-4 py-3 text-sm text-error-600">
                <AlertCircle size={18} className="mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <Input
              label="Email"
              type="email"
              name="email"
              placeholder="you@example.com"
              icon={<Mail size={18} />}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />

            <Input
              label="Password"
              type="password"
              name="password"
              placeholder="Enter your password"
              icon={<Lock size={18} />}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
            />

            <Button type="submit" loading={loading} className="w-full justify-center" size="lg">
              Sign in
              <ArrowRight size={16} />
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-charcoal-400">
            Don't have an account?{' '}
            <Link to="/signup" className="font-500 text-terracotta-400 hover:text-terracotta-500">
              Create one
            </Link>
          </p>

          <p className="mt-8 text-center text-xs text-charcoal-300">
            {BRAND.name} is a catering marketplace serving all 47 counties in Kenya.
          </p>
        </div>
      </div>
    </div>
  );
}
