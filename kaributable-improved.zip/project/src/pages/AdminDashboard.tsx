import { Users, Store, ShieldCheck, Sparkles } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { BRAND } from '@/config/brand';
import { StatCard } from '@/components/ui/StatCard';

export function AdminDashboard() {
  const { profile } = useAuth();

  const stats = [
    { label: 'Total customers', value: '—', icon: Users, hint: 'Counts arrive with admin tools in Phase 2' },
    { label: 'Total vendors', value: '—', icon: Store, hint: 'Counts arrive with admin tools in Phase 2' },
    { label: 'Pending verifications', value: '—', icon: ShieldCheck, hint: 'Verification queue arrives in Phase 2' },
  ];

  return (
    <>
      <div className="mx-auto max-w-5xl">
        <div className="animate-fade-in">
          <span className="badge bg-charcoal-700 text-white">Administrator</span>
          <h1 className="mt-3 font-serif text-3xl font-600 text-charcoal-700">
            Admin overview
          </h1>
          <p className="mt-2 text-sm text-charcoal-400">
            Manage {BRAND.name} — users, vendors, verifications, and platform health.
          </p>
        </div>

        <div className="mt-8 rounded-2xl border border-terracotta-200 bg-terracotta-50 p-6 animate-fade-in-up">
          <div className="flex items-start gap-4">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-terracotta-400 text-white">
              <Sparkles size={20} />
            </div>
            <div>
              <h2 className="font-serif text-lg font-600 text-charcoal-700">
                Admin tools arriving in Phase 2
              </h2>
              <p className="mt-1 text-sm leading-relaxed text-charcoal-500">
                User management, vendor verification queue, bookings oversight, reviews & complaints,
                categories & locations management, and platform analytics will be available in the
                next phase.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {stats.map((stat, i) => (
            <StatCard key={stat.label} {...stat} index={i} />
          ))}
        </div>

        <div className="mt-8 card p-6">
          <h2 className="font-serif text-lg font-600 text-charcoal-700">Your admin account</h2>
          <div className="mt-4 flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-charcoal-700 text-lg font-600 text-white">
              {(profile?.full_name || 'A').charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="font-500 text-charcoal-700">{profile?.full_name || 'Admin'}</p>
              <p className="text-sm text-charcoal-400">{profile?.email}</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
