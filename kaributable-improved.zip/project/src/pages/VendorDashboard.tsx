import { Link } from 'react-router-dom';
import { MessageSquare, Calendar, UtensilsCrossed, BarChart3, ArrowRight, Sparkles, Store } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { BRAND } from '@/config/brand';
import { StatCard } from '@/components/ui/StatCard';

export function VendorDashboard() {
  const { profile } = useAuth();
  const firstName = profile?.full_name?.split(' ')[0] || 'there';

  const stats = [
    { label: 'New enquiries', value: 0, icon: MessageSquare, hint: 'Customers requesting quotes' },
    { label: 'Active bookings', value: 0, icon: Calendar, hint: 'Confirmed upcoming events' },
    { label: 'Profile views', value: 0, icon: BarChart3, hint: 'This month' },
  ];

  const onboardingSteps = [
    { label: 'Create your account', done: true },
    { label: 'Add your business name & description', done: false },
    { label: 'Upload photos of your work', done: false },
    { label: 'Create your first menu', done: false },
    { label: 'Set your service areas', done: false },
    { label: 'Publish your listing', done: false },
  ];

  const completed = onboardingSteps.filter((step) => step.done).length;
  const progress = Math.round((completed / onboardingSteps.length) * 100);

  return (
    <>
      <div className="mx-auto max-w-5xl">
        {/* Greeting */}
        <div className="animate-fade-in">
          <h1 className="font-serif text-3xl font-600 text-charcoal-700">
            Habari, {firstName}.
          </h1>
          <p className="mt-2 text-sm text-charcoal-400">
            Your {BRAND.name} vendor dashboard — manage your profile, enquiries, and bookings.
          </p>
        </div>

        {/* Onboarding progress */}
        <div className="mt-8 card p-6 animate-fade-in-up">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-terracotta-50 text-terracotta-400">
                <Store size={20} />
              </div>
              <div>
                <h2 className="font-serif text-lg font-600 text-charcoal-700">
                  Vendor profile setup
                </h2>
                <p className="text-xs text-charcoal-400">{completed} of {onboardingSteps.length} complete</p>
              </div>
            </div>
            <span className="badge bg-sage-100 text-sage-700">Draft</span>
          </div>

          <div className="mt-5 h-2 overflow-hidden rounded-full bg-beige-200">
            <div className="h-full rounded-full bg-terracotta-400 transition-all duration-500" style={{ width: `${progress}%` }} role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100} aria-label="Vendor profile setup progress" />
          </div>

          <ul className="mt-5 space-y-2">
            {onboardingSteps.map((step) => (
              <li key={step.label} className="flex items-center gap-3 text-sm">
                <span
                  className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-600 ${
                    step.done ? 'bg-sage-400 text-white' : 'bg-beige-200 text-charcoal-400'
                  }`}
                >
                  {step.done ? '✓' : '—'}
                </span>
                <span className={step.done ? 'text-charcoal-500 line-through' : 'text-charcoal-600'}>
                  {step.label}
                </span>
              </li>
            ))}
          </ul>

          <div className="mt-5 rounded-xl border border-sage-200 bg-sage-50 p-4">
            <p className="text-sm font-500 text-sage-700">Coming in Phase 2</p>
            <p className="mt-1 text-xs leading-relaxed text-sage-600">
              Full vendor profile management — business details, photos, menus, packages, service
              areas, availability, and publishing — will be available in the next phase.
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {stats.map((stat, i) => (
            <StatCard key={stat.label} {...stat} index={i} />
          ))}
        </div>

        {/* Quick actions */}
        <div className="mt-8">
          <h2 className="font-serif text-xl font-600 text-charcoal-700">Quick actions</h2>
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Link
              to="/vendor/profile"
              className="card flex items-center gap-4 p-5 hover:shadow-card-hover hover:-translate-y-0.5 transition-all"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-terracotta-50 text-terracotta-400">
                <Store size={20} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-600 text-charcoal-700">Edit business profile</p>
                <p className="text-xs text-charcoal-400">Available in Phase 2</p>
              </div>
              <ArrowRight size={16} className="text-charcoal-300" />
            </Link>
            <Link
              to="/vendor/profile"
              className="card flex items-center gap-4 p-5 hover:shadow-card-hover hover:-translate-y-0.5 transition-all"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sage-50 text-sage-500">
                <UtensilsCrossed size={20} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-600 text-charcoal-700">Create a menu</p>
                <p className="text-xs text-charcoal-400">Available in Phase 2</p>
              </div>
              <ArrowRight size={16} className="text-charcoal-300" />
            </Link>
          </div>
        </div>

        {/* Phase 2 notice */}
        <div className="mt-8 rounded-2xl border border-terracotta-200 bg-terracotta-50 p-6">
          <div className="flex items-start gap-4">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-terracotta-400 text-white">
              <Sparkles size={20} />
            </div>
            <div>
              <h2 className="font-serif text-lg font-600 text-charcoal-700">
                Your marketplace tools are coming
              </h2>
              <p className="mt-1 text-sm leading-relaxed text-charcoal-500">
                Enquiry management, quotation builder, booking accept/decline, messaging, analytics,
                and verification applications will all be available in Phase 2.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
