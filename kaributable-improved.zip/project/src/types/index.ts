export type UserRole = 'customer' | 'vendor' | 'admin';

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  phone: string | null;
  role: UserRole;
  avatar_url: string | null;
  onboarding_complete: boolean;
  created_at: string;
  updated_at: string;
}

export interface AuthContextValue {
  user: { id: string; email: string } | null;
  profile: Profile | null;
  role: UserRole | null;
  loading: boolean;
  /** Signed in but the profile could not be loaded or created. */
  profileError: boolean;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

/** Roles a person may choose at public sign-up. 'admin' is never self-assignable. */
export type SignUpRole = Exclude<UserRole, 'admin'>;

export const dashboardPathFor = (role: UserRole): string => `/${role}`;
