export const BRAND = {
  name: 'KaribuTable',
  tagline: "Kenya's Premium Catering Marketplace",
  description:
    'Find trusted caterers, private chefs, and home-based cooks for every occasion — across all 47 counties.',
  currency: 'KES',
  currencySymbol: 'KSh',
  countryCode: '+254',
  supportEmail: 'hello@kaributable.co.ke',
  // Leave a URL empty to hide that link in the footer until the real one exists.
  social: { instagram: '', twitter: '', facebook: '' },
  legal: { privacy: '', terms: '' },
} as const;

export type Brand = typeof BRAND;
